package mx.edu.utez.Examen.models.productos;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mx.edu.utez.Examen.models.transacciones.Transacciones;

import javax.persistence.*;

@Entity
@Table(name= "products")
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter

public class Productos {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //es como un auto incrementable
    private Long id;

    @Column(unique = true, nullable = false, length = 150)
    private String nameProduct;

    @Column(unique = true, nullable = false, length = 150)
    private String categoryProduct;


    @Column(unique = true, nullable = false, length = 150)
    private Integer price;
    @Column(name = "status", nullable = false, columnDefinition = "tinyint default 1")
    private Boolean status;


    @OneToOne(mappedBy = "productos",
            cascade = CascadeType.ALL,
            optional = false)
    private Transacciones transacciones;




    public Productos(Long id, String nameProduct, String categoryProduct, Integer price, Boolean status) {
        this.id = id;
        this.nameProduct = nameProduct;
        this.categoryProduct = categoryProduct;
        this.price = price;
        this.status = status;
    }
}
