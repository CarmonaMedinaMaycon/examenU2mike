package mx.edu.utez.Examen.services.transaccionesServices;

public class TransaccionesServices {
}
