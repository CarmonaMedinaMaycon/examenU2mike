package mx.edu.utez.Examen.models.transacciones;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mx.edu.utez.Examen.models.productos.Productos;
import mx.edu.utez.Examen.models.usuarios.Usuarios;

import javax.persistence.*;

@Entity
@Table(name= "transactions")
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class Transacciones {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //es como un auto incrementable
    private Long id;

    @OneToOne
    @JoinColumn(name="products_id",
            referencedColumnName = "id", unique = true)
    @JsonIgnore
        private Productos productos;

    @OneToOne
    @JoinColumn(name="user_id",
            referencedColumnName = "id", unique = true)
    @JsonIgnore
    private Usuarios user;

    @Column(nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private String date;
}
