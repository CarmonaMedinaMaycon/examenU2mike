package mx.edu.utez.Examen.controllers.transacciones.dto;

public class TransaccionesDto {
}
