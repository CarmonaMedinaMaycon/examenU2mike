package mx.edu.utez.Examen.services.usuariosServices;


import mx.edu.utez.Examen.models.productos.Productos;
import mx.edu.utez.Examen.models.usuarios.Usuarios;
import mx.edu.utez.Examen.models.usuarios.UsuariosRepository;
import mx.edu.utez.Examen.utils.CustomResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.SQLException;
import java.util.List;

@Service
@Transactional
public class UsuariosServices {

    @Autowired
    private UsuariosRepository repository;

    @Transactional(readOnly = true)
    public CustomResponse<List<Usuarios>> getAll() {
        return new CustomResponse<>(
                this.repository.findAll(),
                false,
                200,
                "OK infiel"
        );
    }

    @Transactional(readOnly = true)
    public CustomResponse<Usuarios> getOne(Long id) {
        return new CustomResponse<>(
                this.repository.findById(id).get(),
                false,
                200,
                "OK infiel"
        );
    }

    @Transactional(rollbackFor = {SQLException.class})
    public CustomResponse<Usuarios> insert(Usuarios users) {

        return new CustomResponse<>(
                this.repository.saveAndFlush(users),
                false,
                200,
                "OK"
        );
    }

    @Transactional(rollbackFor = {SQLException.class})
    public CustomResponse<Usuarios> update(Usuarios users) {
        if (!this.repository.existsById(users.getId())) {
            return new CustomResponse<>(
                    null,
                    true,
                    400,
                    "No existe"
            );
        }
        return new CustomResponse<>(
                this.repository.saveAndFlush(users),
                false,
                200,
                "OK"
        );
    }

    @Transactional(rollbackFor = {SQLException.class})
    public CustomResponse<Integer> changeStatus(Usuarios users) {
        if (!this.repository.existsById(users.getId())) {
            return new CustomResponse<>(
                    0,
                    true,
                    400,
                    "no jalo"
            );
        }
        return new CustomResponse<>(
                this.repository.updateStatusById(
                        users.getStatus(), users.getId()
                ),
                false,
                200,
                "OK"
        );
    }


}
