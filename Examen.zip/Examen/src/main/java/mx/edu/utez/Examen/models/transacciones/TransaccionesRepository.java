package mx.edu.utez.Examen.models.transacciones;

public interface TransaccionesRepository {
}
