package mx.edu.utez.Examen.models.usuarios;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mx.edu.utez.Examen.models.transacciones.Transacciones;

import javax.persistence.*;

@Entity
@Table(name= "users")
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class Usuarios {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    @Column(unique = true, nullable = false, length = 150)
    private String name;


    @Column(unique = true, nullable = false, length = 150)
    private String lastname;


    @Column(unique = true, nullable = false, length = 150)
    private String email;

    @Column(unique = true, nullable = false, length = 150)
    private String password;


    @Column(unique = true, nullable = false, length = 150)
    private String listWish;


    @Column(name = "status", nullable = false, columnDefinition = "tinyint default 1")
    private Boolean status;


    @OneToOne(mappedBy = "user",
            cascade = CascadeType.ALL,
            optional = false)
    private Transacciones transacciones;


    public Usuarios(Long id, String name, String lastname, String email, String password, String listWish, Boolean status) {
        this.id = id;
        this.name = name;
        this.lastname = lastname;
        this.email = email;
        this.password = password;
        this.listWish = listWish;
        this.status = status;
    }
}
