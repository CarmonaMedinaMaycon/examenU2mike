package mx.edu.utez.Examen.controllers.transacciones;

public class TransaccionesController {
}
