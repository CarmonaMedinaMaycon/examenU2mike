package mx.edu.utez.Examen.services.productosServices;

import mx.edu.utez.Examen.models.productos.Productos;
import mx.edu.utez.Examen.models.productos.ProductsRepository;
import mx.edu.utez.Examen.utils.CustomResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.SQLException;
import java.util.List;

@Service
@Transactional
public class ProductsServices {


    @Autowired
    private ProductsRepository repository;

    @Transactional(readOnly = true)
    public CustomResponse<List<Productos>> getAll() {
        return new CustomResponse<>(
                this.repository.findAll(),
                false,
                200,
                "OK infiel"
        );
    }


    @Transactional(readOnly = true)
    public CustomResponse<Productos> getOne(Long id) {
        return new CustomResponse<>(
                this.repository.findById(id).get(),
                false,
                200,
                "OK infiel"
        );
    }

    @Transactional(rollbackFor = {SQLException.class})
    public CustomResponse<Productos> insert(Productos products) {

        return new CustomResponse<>(
                this.repository.saveAndFlush(products),
                false,
                200,
                "OK"
        );
    }

    @Transactional(rollbackFor = {SQLException.class})
    public CustomResponse<Productos> update(Productos products) {
        if (!this.repository.existsById(products.getId())) {
            return new CustomResponse<>(
                    null,
                    true,
                    400,
                    "No existe"
            );
        }
        return new CustomResponse<>(
                this.repository.saveAndFlush(products),
                false,
                200,
                "OK"
        );
    }

    @Transactional(rollbackFor = {SQLException.class})
    public CustomResponse<Integer> changeStatus(Productos products) {
        if (!this.repository.existsById(products.getId())) {
            return new CustomResponse<>(
                    0,
                    true,
                    400,
                    "no jalo"
            );
        }
        return new CustomResponse<>(
                this.repository.updateStatusById(
                        products.getStatus(), products.getId()
                ),
                false,
                200,
                "OK"
        );
    }
}
