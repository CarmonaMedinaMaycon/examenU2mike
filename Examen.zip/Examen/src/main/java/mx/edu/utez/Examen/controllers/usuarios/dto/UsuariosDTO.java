package mx.edu.utez.Examen.controllers.usuarios.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mx.edu.utez.Examen.models.productos.Productos;
import mx.edu.utez.Examen.models.usuarios.Usuarios;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class UsuariosDTO {


    private Long  id;
    @NotEmpty(message = "chinga TU MADRE")
    @Size(min=3, max=50)
    //Notación para indicar que el tamaño minimo debe ser 0
    private String name;

    @NotEmpty(message = "chinga TU MADRE")
    @Size(min=3, max=50)
    private String lastname;
    @NotEmpty
    private String email;

    @NotEmpty
    private String password;

    @NotEmpty
    private String listWish;


    private Boolean status = true;

    public Usuarios castToUsuarios(){
        return new Usuarios(
                getId(),
                getName(),
                getLastname(),
                getEmail(),
                getPassword(),
                getListWish(),
                getStatus()
        );
    }

    public Usuarios changeStatus(){
        return new Usuarios(
                null,
                null,
                null,
                null,
                null,
                null,
                getStatus()
        );
    }



}
