package mx.edu.utez.Examen.controllers.productos.dtos;

import lombok.*;
import mx.edu.utez.Examen.models.productos.Productos;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class ProductsDTO {


    private Long  id;
    @NotEmpty(message = "chinga TU MADRE")
    @Size(min=3, max=50)
    //Notación para indicar que el tamaño minimo debe ser 0
    private String nameProduct;

    @NotEmpty(message = "chinga TU MADRE")
    @Size(min=3, max=50)
    private String categoryProduct;
    @NotEmpty
    private Integer price;
    private Boolean status = true;

        public Productos castToProducts(){
            return new Productos(
                    getId(),
                    getNameProduct(),
                    getCategoryProduct(),
                    getPrice(),
                    getStatus()
            );
        }

        public Productos changeStatus(){
            return new Productos(
                null,
                    null,
                    null,
                    null,
                    getStatus()
            );
        }



}
