package mx.edu.utez.Examen.controllers.usuarios;


import mx.edu.utez.Examen.controllers.productos.dtos.ProductsDTO;
import mx.edu.utez.Examen.controllers.usuarios.dto.UsuariosDTO;
import mx.edu.utez.Examen.models.productos.Productos;
import mx.edu.utez.Examen.models.usuarios.Usuarios;
import mx.edu.utez.Examen.services.productosServices.ProductsServices;
import mx.edu.utez.Examen.services.usuariosServices.UsuariosServices;
import mx.edu.utez.Examen.utils.CustomResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api-examen/users")
@CrossOrigin(origins = {"*"})
public class UsuariosController {
    @Autowired
    private UsuariosServices service;

    @GetMapping("/")
    public ResponseEntity<CustomResponse<List<Usuarios>>> getAll() {
        return new ResponseEntity<>(
                this.service.getAll(),
                HttpStatus.OK
        );
    }



    @GetMapping("/{id}")
    public ResponseEntity<CustomResponse<Usuarios>> getOne(@PathVariable("id") Long id) {
        return new ResponseEntity<>(
                this.service.getOne(id),
                HttpStatus.OK
        );
    }

    @PostMapping("/")
    public ResponseEntity<CustomResponse<Usuarios>> saveCategory(@RequestBody UsuariosDTO users, @Valid BindingResult result) {
        if (result.hasErrors()) {
            return new ResponseEntity<>(
                    null,
                    HttpStatus.BAD_REQUEST
            );
        }
        return new ResponseEntity<>(
                this.service.insert(users.castToUsuarios()),
                HttpStatus.CREATED
        );
    }

    @PutMapping("/")
    public ResponseEntity<CustomResponse<Usuarios>> updateCategory(@RequestBody UsuariosDTO users, @Valid BindingResult result) {
        if (result.hasErrors()) {
            return new ResponseEntity<>(
                    null,
                    HttpStatus.BAD_REQUEST
            );
        }
        return new ResponseEntity<>(
                this.service.update(users.castToUsuarios()),
                HttpStatus.CREATED
        );
    }

    @PatchMapping("/")
    public ResponseEntity<CustomResponse<Integer>> enableOrDisable(
            @RequestBody UsuariosDTO usuariosDTO) {
        return new ResponseEntity<>(
                this.service.changeStatus(usuariosDTO.changeStatus()),
                HttpStatus.OK
        );
    }


}
